export interface CustomError extends Error {
    status?: string;
}
